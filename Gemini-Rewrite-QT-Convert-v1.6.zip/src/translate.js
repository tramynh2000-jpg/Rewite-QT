load("defaults.js");
load("common.js");

function execute(text, from, to, source) {
    return AT_run(text, from, to, source);
}
