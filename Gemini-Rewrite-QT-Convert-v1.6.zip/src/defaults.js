// File sinh tự động bởi build.py, không sửa tay.
var AT_DEFAULTS = {
  "models": "gemini-3.1-flash-lite",
  "styles": [
    {
      "name": "Ta Ngươi Hắn Nàng",
      "prompt": "Giới tính nam ở ngôi thứ ba = hắn. Giới tính nữ ở ngôi thứ ba = nàng. Ngôi thứ nhất nói chung = ta. Ngôi thứ hai nói chung = ngươi. KHÔNG DÙNG CÁC ĐẠI TỪ KHÁC như cậu, anh, cô, v.v. CHỈ DÙNG ta, ngươi, hắn, nàng (các từ chỉ quan hệ như mẹ, anh, chị, em gái... trong bảng quy đổi vẫn dùng bình thường khi nói về người thân). Nếu bản gốc không rõ giới tính thì DỊCH NHƯ BẢN GỐC, KHÔNG TỰ Ý THÊM ĐẠI TỪ, không tự suy đoán."
    },
    {
      "name": "Hiện đại",
      "prompt": "Bối cảnh hiện đại: xưng hô tôi, anh, em, cậu, cô, chú, bác, mày, tao... theo vai vế và mức thân thiết. Ngôi thứ ba dùng anh ấy, cô ấy, hắn, cô ta... theo ngữ cảnh. Giới tính nhân vật giữ đúng theo bản gốc."
    },
    {
      "name": "Cổ trang",
      "prompt": "Bối cảnh cổ đại, tiên hiệp, huyền huyễn: xưng hô ta, ngươi, hắn, nàng, y, ngài, các hạ, tại hạ... theo vai vế và hoàn cảnh. Giới tính nhân vật giữ đúng theo bản gốc."
    }
  ],
  "table": "ta=ta;ngươi=ngươi;hắn=hắn;nàng=nàng;mụ mụ=mẹ;ca ca=anh;tỷ tỷ=chị;muội muội=em gái;đệ đệ=em trai;nãi nãi=bà;cữu cữu=chú;lão công=chồng;lão bà=vợ;tẩu tử=chị dâu;nhĩ tiêm=vành tai;gia gia=ông"
};
var AT_NAME = "Gemini Rewrite QT-Convert";
var AT_VERSION = "v1.6";
