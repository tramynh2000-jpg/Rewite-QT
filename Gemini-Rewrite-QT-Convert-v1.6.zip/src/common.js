// Gemini Rewrite QT-Convert - lõi dùng chung. Viết theo ES5 cho an toàn với engine của vBook.
// Biến và hàm toàn cục đều có tiền tố AT_ để không đụng với hằng số cấu hình do app inject.
// AT_DEFAULTS, AT_NAME, AT_VERSION nằm trong defaults.js (sinh bởi build.py).

var AT_BASE = "https://generativelanguage.googleapis.com/v1beta/models/";
var AT_SLOTS = 6;
var AT_HOUR = 3600000;
var AT_WIN = 60500;      // cửa sổ trượt 60 giây cộng 0,5 giây an toàn
var AT_SPILL = 20000;    // chờ tối đa 20 giây (quá thì dùng model kế tiếp nếu có, không có thì báo lỗi và dừng)
var AT_MAX_WAIT = 120000; // tổng thời gian chờ tối đa cho một lần gọi AI
var AT_CYCLES = 2;       // mỗi cặp model/key được thử tối đa 2 vòng cho một lần gọi AI

var AT_SAFETY = [
    { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
    { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
    { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
    { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
];

// ---------- cấu hình ----------

var AT_GLOBAL = (function () { return this; })();

// Trả về chuỗi đã lưu (có thể rỗng) hoặc null nếu chưa từng đặt.
function AT_cfgExact(key) {
    var v = null;
    try { v = localConfig.getItem(key); } catch (e) { v = null; }
    if (v === null || v === undefined || String(v) === "null" || String(v) === "undefined") {
        // Một số bản vBook inject cấu hình thành biến toàn cục.
        try { v = AT_GLOBAL ? AT_GLOBAL[key] : null; } catch (e2) { v = null; }
    }
    if (v === null || v === undefined || String(v) === "null" || String(v) === "undefined") return null;
    return String(v);
}

function AT_cfg(key, def) {
    var v = AT_cfgExact(key);
    if (v === null) return def;
    v = v.replace(/^\s+|\s+$/g, "");
    return v === "" ? def : v;
}

function AT_trim(s) { return String(s || "").replace(/^\s+|\s+$/g, ""); }

function AT_split(s, re) {
    var parts = String(s || "").split(re);
    var out = [];
    for (var i = 0; i < parts.length; i++) {
        var p = parts[i].replace(/^[\s"'`]+|[\s"'`]+$/g, "");
        if (p) out.push(p);
    }
    return out;
}

function AT_hash(s) {
    var h = 5381;
    s = String(s);
    for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
}

function AT_log(msg) { try { console.log("[AT] " + msg); } catch (e) {} }

function AT_cjkCount(s) {
    var m = String(s).match(/[㐀-鿿]/g);
    return m ? m.length : 0;
}

// Danh sách phong cách dịch: slot nào có tên thì hiện trong ô chọn phần dịch.
function AT_styles() {
    var out = [];
    var defs = (typeof AT_DEFAULTS !== "undefined" && AT_DEFAULTS.styles) ? AT_DEFAULTS.styles : [];
    for (var i = 1; i <= AT_SLOTS; i++) {
        var def = defs[i - 1] || { name: "", prompt: "" };
        var raw = AT_cfgExact("style_" + i + "_name");
        var name = raw === null ? def.name : AT_trim(raw);
        if (!name) continue;
        var prompt = AT_cfg("style_" + i + "_prompt", def.prompt);
        if (!prompt) prompt = "Xưng hô tự nhiên theo bối cảnh và giữ đúng giới tính nhân vật theo bản gốc.";
        out.push({ id: "s" + i, name: name, prompt: prompt });
    }
    if (!out.length && defs.length) {
        out.push({ id: "s1", name: defs[0].name, prompt: defs[0].prompt });
    }
    return out;
}

function AT_pickStyle(styles, to) {
    var t = AT_trim(to);
    for (var i = 0; i < styles.length; i++) {
        if (styles[i].id === t || styles[i].name === t) return styles[i];
    }
    return styles[0];
}

function AT_pairs(s) {
    var out = [];
    var parts = AT_split(s, /[\n;]+/);
    for (var i = 0; i < parts.length; i++) {
        var eq = parts[i].indexOf("=");
        if (eq <= 0) continue;
        var a = AT_trim(parts[i].slice(0, eq));
        var b = AT_trim(parts[i].slice(eq + 1));
        if (a && b) out.push([a, b]);
    }
    return out;
}

function AT_num(key, def, min, max, isInt) {
    var v = AT_cfg(key, null);
    if (v === null) return def;
    var n = parseFloat(String(v).replace(",", "."));
    if (isNaN(n)) return def;
    if (isInt) n = Math.round(n);
    if (n < min) n = min;
    if (n > max) n = max;
    return n;
}

function AT_loadConfig(to) {
    var keys = AT_split(AT_cfg("api_keys", ""), /[\s,;]+/);
    var models = AT_split(AT_cfg("models", AT_DEFAULTS.models), /[\s,;]+/);

    if (!keys.length) {
        var dbg = AT_cfgExact("api_keys");
        return { error: "Chưa đọc được API key (nhận " + (dbg ? dbg.length : 0) + " ký tự). Hãy nhập lại vào ô API key trong cài đặt extension này, bấm lưu, rồi thử lại." };
    }
    if (!models.length) return { error: "Chưa nhập model." };

    var keyList = [];
    for (var k = 0; k < keys.length; k++) keyList.push({ key: keys[k], kid: "k" + AT_hash(keys[k]) });

    var style = AT_pickStyle(AT_styles(), to);

    var cfg = {
        keys: keyList,
        models: models,
        style: style,
        temperature: AT_num("temperature", null, 0, 2, false),
        topP: AT_num("top_p", null, 0, 1, false),
        topK: AT_num("top_k", null, 1, 100, true),
        rpm: AT_num("rpm", 15, 1, 15, true),
        chunkChars: AT_num("chunk_chars", 30000, 500, 120000, true),
        chunkLines: 1500,
        timeout: AT_num("timeout", 120000, 5000, 600000, true),
        rewriteToc: AT_cfg("rewrite_toc", "false") === "true",
        glossary: AT_pairs(AT_cfg("glossary", "")),
        table: AT_pairs(AT_cfg("conversion_table", AT_DEFAULTS.table)),
        characters: []
    };

    var chars = AT_pairs(AT_cfg("characters", ""));
    for (var c = 0; c < chars.length; c++) cfg.characters.push(chars[c][0] + ": " + chars[c][1]);

    cfg.sig = AT_hash([
        style.id, style.prompt, cfg.glossary.join("|"), cfg.characters.join("|"),
        cfg.table.join("|"), cfg.temperature, cfg.topP, cfg.topK, "v1"
    ].join("#"));
    return cfg;
}

// ---------- prompt ----------

function AT_system(cfg, note) {
    var s = [];
    function rule(title, items) {
        s.push('<rule title="' + title + '">');
        for (var i = 0; i < items.length; i++) s.push("<item>" + items[i] + "</item>");
        s.push("</rule>");
    }

    s.push("<prompt>");
    s.push("<role>Bạn là một BIÊN TẬP VIÊN CHUYÊN NGHIỆP. Nhiệm vụ của bạn là mài giũa văn bản convert thô (QT/VietPhrase) thành một tác phẩm tiếng Việt hoàn chỉnh, mượt mà và dễ đọc.</role>");
    s.push("<objective>Biên tập lại văn bản convert thô được cung cấp thành tiếng Việt mượt mà, tự nhiên và trôi chảy, loại bỏ hoàn toàn sự lủng củng, tối nghĩa của văn bản gốc. Diễn đạt đúng ngữ pháp tiếng Việt.</objective>");
    s.push("<constraints>");

    rule("LÀM MƯỢT CÂU VĂN", [
        "Viết lại các câu lủng củng, tối nghĩa, sai ngữ pháp.",
        "Nhiều câu đang dùng ngữ pháp tiếng Trung, hãy suy ra ý và chuyển sang ngữ pháp tiếng Việt.",
        "Sắp xếp lại trật tự từ để câu văn tự nhiên theo văn phong tiếng Việt nhưng vẫn giữ nguyên nhịp điệu cảm xúc."
    ]);

    rule("VIỆT HÓA TỪ NGỮ", [
        "Chủ động thay thế các âm Hán-Việt bằng từ thuần Việt tương đương. Lời văn đúng ngữ pháp tiếng Việt.",
        "Ví dụ: thân hình hóa tác nhất đạo lưu quang → thân hình hóa thành một vệt sáng.",
        "KHÔNG ĐỆM TỪ CUỐI CÂU. Ví dụ: Ta không lấy, không viết thành Ta không lấy đâu.",
        "Khi xuất hiện tên + chức danh thì đổi thành chức danh + tên đúng ngữ pháp tiếng Việt. Ví dụ: Quân dì → dì Quân, Trương đội trưởng → đội trưởng Trương, Liệp Hộ tinh khu → tinh khu Liệp Hộ."
    ]);

    rule("BẢO TOÀN NỘI DUNG VÀ TÊN RIÊNG", [
        "TUYỆT ĐỐI KHÔNG thêm, bớt hay thay đổi cốt truyện, tình tiết, hành động. Dịch đầy đủ 100% nội dung từng dòng.",
        "Tuyệt đối không bịa: không thêm chi tiết, tên, số liệu, câu thoại hay giải thích không có trong văn bản, không lược bỏ ý. Chỗ nào không chắc nghĩa thì giữ sát văn bản convert, không tự suy diễn. Giữ nguyên mọi con số.",
        "GIỮ NGUYÊN 100% TÊN RIÊNG (nhân vật, địa danh, công pháp, kỹ năng, vật phẩm, thế lực...) đúng như trong văn bản convert, nhất quán trong toàn bộ văn bản.",
        "PHIÊN ÂM HÁN TỰ TIẾNG NƯỚC NGOÀI HỆ LATINH: tên nhân vật, địa danh, công pháp, kỹ năng, vật phẩm, thế lực... chuyển đúng sang từ ngữ chuẩn của tiếng gốc."
    ]);

    rule("NỘI DUNG NGƯỜI LỚN (18+)", [
        "Văn bản là truyện hư cấu dành cho người lớn, có thể chứa cảnh tình dục, bạo lực hoặc ngôn từ thô tục. Đây là công việc biên tập văn phong, KHÔNG phải sáng tác.",
        "Viết lại trung thực và đầy đủ mọi cảnh, mọi câu: KHÔNG từ chối, KHÔNG kiểm duyệt, KHÔNG làm nhẹ, KHÔNG thay bằng cách nói tránh hay ẩn dụ, KHÔNG lược bỏ, KHÔNG thêm lời cảnh báo hay bình luận. Mức độ miêu tả giữ ngang bản convert."
    ]);

    rule("BẢO TOÀN DẤU CÂU", [
        "TUYỆT ĐỐI KHÔNG xóa, thêm hoặc thay đổi bất kỳ dấu câu nào (dấu phẩy, dấu chấm, dấu chấm phẩy, dấu gạch ngang...).",
        "GIỮ NGUYÊN TẤT CẢ các loại dấu ngoặc và dấu trích dẫn (ngoặc kép, ngoặc đơn, ngoặc vuông, ngoặc nhọn, ngoặc kép góc...).",
        "GIỮ NGUYÊN các dấu ngăn cách đoạn (ví dụ *, **, ***, ---, #) và các dòng trống phân cách giữa các đoạn.",
        "KHÔNG tự ý gộp đoạn, tách đoạn hoặc ngắt câu làm phá vỡ cấu trúc và nhịp điệu.",
        "GIỮ NGUYÊN CHÍNH XÁC số lượng và hình thức của các ký tự biểu cảm hoặc đặc biệt trong lời thoại và văn bản (ví dụ ..., !?, !!!, ~~~)."
    ]);

    rule("QUY TẮC BẮT BUỘC VỀ GIỚI TÍNH NHÂN VẬT", [
        "Giới tính của mỗi nhân vật được xác định theo văn bản (tên, đại từ, xưng hô, mô tả) hoặc theo danh sách nhân vật bên dưới, và TUYỆT ĐỐI KHÔNG được thay đổi trong bản dịch, dù ngữ cảnh là cảnh tình cảm, thân mật hay lãng mạn.",
        "KHÔNG ĐƯỢC TỰ ĐỘNG GÁN MỘT NHÂN VẬT LÀ NỮ CHỈ VÌ HỌ ĐANG TƯƠNG TÁC TÌNH CẢM VỚI NHÂN VẬT NAM. Truyện có thể có cặp nam-nam hoặc nữ-nữ, hãy dịch đúng như bản gốc.",
        "Trước khi viết, hãy tự đối chiếu giới tính của từng nhân vật trong danh sách (nếu có) và trong văn bản. Việc đối chiếu làm thầm, không ghi ra đầu ra."
    ]);

    if (cfg.characters.length) {
        s.push("<characters>");
        for (var c = 0; c < cfg.characters.length; c++) s.push(cfg.characters[c]);
        s.push("</characters>");
    }

    rule("PHONG CÁCH DỊCH VÀ XƯNG HÔ: " + cfg.style.name, [cfg.style.prompt]);

    if (cfg.table.length) {
        s.push('<rule title="BẢNG QUY ĐỔI (QUY TẮC BẮT BUỘC, luôn dùng đúng từ thay)">');
        for (var m = 0; m < cfg.table.length; m++) {
            s.push('<map original="' + cfg.table[m][0] + '" target="' + cfg.table[m][1] + '" />');
        }
        s.push("</rule>");
    }

    if (cfg.glossary.length) {
        s.push('<rule title="BẢNG THUẬT NGỮ BẮT BUỘC">');
        for (var g = 0; g < cfg.glossary.length; g++) {
            s.push('<map original="' + cfg.glossary[g][0] + '" target="' + cfg.glossary[g][1] + '" />');
        }
        s.push("</rule>");
    }
    s.push("</constraints>");

    s.push("<output_format>");
    s.push("<requirements>");
    s.push("<item>Đầu vào gồm các mục có nhãn [n]. Giữ nguyên số mục và nhãn [n]. Mỗi nhãn đúng một dòng đầu ra, bắt đầu bằng nhãn [n] tương ứng, không gộp, không tách, không bỏ mục nào.</item>");
    s.push("<item>CHỈ trả về văn bản tiếng Việt đã được viết lại, tuyệt đối không kèm chú thích, giải thích hay lời mở đầu hoặc kết thúc.</item>");
    s.push("<item>100% Việt hóa: loại bỏ hoàn toàn pinyin hoặc ký tự Trung Quốc sót lại.</item>");
    s.push("</requirements>");
    s.push("<limitations>TUYỆT ĐỐI KHÔNG sử dụng Markdown (như in đậm, in nghiêng) trong nội dung trả về.</limitations>");
    s.push("</output_format>");

    s.push("<examples><example>");
    s.push("<original_text>[1] Ngã tâm niệm nhất động, thân hình hóa tác nhất đạo lưu quang, hướng về viễn phương bạo xạ nhi khứ.</original_text>");
    s.push("<desired_result>[1] Tâm niệm ta khẽ động, thân hình hóa thành một vệt sáng, lao vút về phía xa.</desired_result>");
    s.push("</example></examples>");
    s.push("</prompt>");
    if (note) s.push(note);
    return s.join("\n");
}

function AT_buildUser(items, idxs) {
    var out = [];
    for (var i = 0; i < idxs.length; i++) out.push("[" + (i + 1) + "] " + items[idxs[i]].src);
    return out.join("\n");
}

// ---------- xử lý văn bản ----------

function AT_clean(text) {
    text = String(text || "");
    text = text.replace(/<think>[\s\S]*?<\/think>/gi, "");
    text = text.replace(/^```[a-z]*\s*$/gim, "");
    return text;
}

// Trả về { n: "văn bản" } cho các nhãn hợp lệ 1..n (nhãn trùng giữ cái đầu, nhãn thừa bỏ).
function AT_parseLoose(text, n) {
    var lines = AT_clean(text).split(/\r?\n/);
    var got = {};
    var cur = -1;
    for (var i = 0; i < lines.length; i++) {
        var m = /^\s*\[(\d+)\]\s*(.*)$/.exec(lines[i]);
        if (m) {
            var id = parseInt(m[1], 10);
            if (id >= 1 && id <= n && got[id] === undefined) {
                cur = id;
                got[id] = m[2];
            } else {
                cur = -1;
            }
        } else if (cur > 0 && AT_trim(lines[i])) {
            got[cur] += " " + AT_trim(lines[i]);
        }
    }
    for (var k in got) got[k] = AT_trim(got[k]);
    return got;
}

function AT_hasLetter(s) { return /[A-Za-z0-9À-ỹ㐀-鿿]/.test(s); }

function AT_qt(line, source) {
    if (typeof Qt === "undefined") return null;
    try {
        var extras = { first_capitalize: true };
        if (source === "tableOfContent") extras.chapter_name = true;
        var r = Qt.translate(line, "vp", extras);
        if (r && r.translateText) return String(r.translateText);
    } catch (e) {}
    return null;
}

function AT_count(s, ch) {
    var n = 0, i = -1;
    while ((i = s.indexOf(ch, i + 1)) >= 0) n++;
    return n;
}

var AT_PAIRS = ["“", "”", "「", "」", "『", "』", "【", "】", "[", "]", "(", ")", "（", "）", "\""];

// Kiểm tra từng dòng, chỉ dựa vào tín hiệu rõ ràng để không loại nhầm (mỗi lần loại nhầm tốn thêm một lượt gọi).
function AT_lineOK(item, out) {
    var src = item.src;
    if (!out) return false;
    var nums = src.match(/\d+/g);
    if (nums) {
        for (var i = 0; i < nums.length; i++) if (out.indexOf(nums[i]) < 0) return false;
    }
    var oc = AT_cjkCount(out);
    if (oc > 0 && oc > AT_cjkCount(src) * 0.3) return false;
    if (src.length >= 25) {
        var ratio = out.length / src.length;
        if (ratio < 0.5 || ratio > 2.0) return false;
    }
    for (var p = 0; p < AT_PAIRS.length; p++) {
        if (AT_count(src, AT_PAIRS[p]) !== AT_count(out, AT_PAIRS[p])) return false;
    }
    return true;
}

// ---------- bảng quy đổi bắt buộc ----------

function AT_isLetter(ch) { return !!ch && ch.toLowerCase() !== ch.toUpperCase(); }

function AT_replaceTerm(text, from, to) {
    var lt = text.toLowerCase();
    var lf = from.toLowerCase();
    if (lt.length !== text.length || !lf) return text;
    var out = "", i = 0;
    while (true) {
        var k = lt.indexOf(lf, i);
        if (k < 0) { out += text.slice(i); break; }
        var before = k > 0 ? text.charAt(k - 1) : "";
        var after = text.charAt(k + from.length);
        if (AT_isLetter(before) || AT_isLetter(after)) {
            out += text.slice(i, k + from.length);
            i = k + from.length;
            continue;
        }
        var rep = to;
        var first = text.charAt(k);
        if (first !== first.toLowerCase()) rep = to.charAt(0).toUpperCase() + to.slice(1);
        out += text.slice(i, k) + rep;
        i = k + from.length;
    }
    return out;
}

function AT_applyTable(text, table) {
    for (var i = 0; i < table.length; i++) {
        if (table[i][0].toLowerCase() === table[i][1].toLowerCase()) continue;
        text = AT_replaceTerm(text, table[i][0], table[i][1]);
    }
    return text;
}

function AT_finish(cfg, item, out) {
    if (item.src.indexOf("*") < 0) out = out.replace(/\*+/g, "");
    return AT_applyTable(out, cfg.table);
}

// ---------- trạng thái dùng chung (cooldown, giới hạn tốc độ) ----------

function AT_state() {
    try {
        var s = cacheStorage.getItem("at_state");
        if (s) {
            var o = JSON.parse(s);
            if (o && typeof o === "object") return o;
        }
    } catch (e) {}
    return {};
}

function AT_saveState(st) {
    try { cacheStorage.setItem("at_state", JSON.stringify(st)); } catch (e) {}
}

function AT_isCool(st, id) {
    return !!(st.cool && st.cool[id] && st.cool[id] > Date.now());
}

function AT_setCool(id, ms, why) {
    var st = AT_state();
    if (!st.cool) st.cool = {};
    if (!st.why) st.why = {};
    st.cool[id] = Date.now() + ms;
    st.why[id] = why || "";
    for (var k in st.cool) if (st.cool[k] <= Date.now()) delete st.cool[k];
    AT_saveState(st);
}

// Gom lý do các cặp model/key đang bị tạm ngưng để báo cho người dùng.
function AT_why(st, combos) {
    var seen = {}, out = [];
    for (var i = 0; i < combos.length; i++) {
        var ids = ["m:" + combos[i].model, "k:" + combos[i].kid, "c:" + combos[i].id, "f:" + combos[i].id];
        for (var j = 0; j < ids.length; j++) {
            var until = st.cool && st.cool[ids[j]];
            if (until && until > Date.now()) {
                var w = (st.why && st.why[ids[j]]) || "lỗi không rõ";
                var mins = Math.ceil((until - Date.now()) / 60000);
                var t = w + (mins > 1 ? " (thử lại sau khoảng " + mins + " phút)" : "");
                if (!seen[t]) { seen[t] = true; out.push(t); }
            }
        }
    }
    return out.join("; ");
}

// Khoảng cách tối thiểu giữa hai yêu cầu liên tiếp: giãn đều thay vì dồn cục rồi chờ cả phút.
// Sau một lần bị 429 theo phút thì giãn rộng thêm 50% trong 2 phút.
function AT_interval(st, id, cfg, now) {
    var base = Math.ceil(60000 / cfg.rpm) + 100;
    return (st.slow && st.slow[id] && st.slow[id] > now) ? Math.ceil(base * 1.5) : base;
}

// Thời gian phải chờ (ms) để gửi yêu cầu mới: thỏa cả khoảng cách tối thiểu lẫn cửa sổ trượt 60 giây.
function AT_waitFor(st, id, cfg, now) {
    var w = ((st.nx && st.nx[id]) || 0) - now;
    var arr = (st.rl && st.rl[id]) || [];
    var live = [];
    for (var i = 0; i < arr.length; i++) if (arr[i] > now - AT_WIN) live.push(arr[i]);
    if (live.length >= cfg.rpm) {
        live.sort(function (a, b) { return a - b; });
        var w2 = live[live.length - cfg.rpm] + AT_WIN - now;
        if (w2 > w) w = w2;
    }
    return w > 0 ? w : 0;
}

// Ghi nhận một yêu cầu sẽ được gửi vào thời điểm t.
function AT_reserve(cfg, id, t) {
    var st = AT_state();
    var now = Date.now();
    if (!st.rl) st.rl = {};
    if (!st.nx) st.nx = {};
    var live = [];
    var arr = st.rl[id] || [];
    for (var i = 0; i < arr.length; i++) if (arr[i] > now - AT_WIN) live.push(arr[i]);
    live.push(t);
    st.rl[id] = live;
    st.nx[id] = t + AT_interval(st, id, cfg, now);
    AT_saveState(st);
}

// Chờ tới lượt rồi giữ chỗ (dùng cho lần thử lại).
function AT_slot(cfg, id) {
    var waited = 0;
    while (waited < 60000) {
        var w = AT_waitFor(AT_state(), id, cfg, Date.now());
        if (w <= 0) break;
        var d = Math.min(w, 15000);
        sleep(d);
        waited += d;
    }
    AT_reserve(cfg, id, Date.now());
}

// ---------- gọi Gemini ----------

function AT_http(cfg, c, system, user, temp, useSampling) {
    var gen = { maxOutputTokens: 32768 };
    if (temp !== null && temp !== undefined) gen.temperature = temp;
    if (useSampling) {
        if (cfg.topP !== null) gen.topP = cfg.topP;
        if (cfg.topK !== null) gen.topK = cfg.topK;
    }
    var body = {
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: user }] }],
        generationConfig: gen,
        safetySettings: AT_SAFETY
    };

    var res = { ok: false, blocked: false, status: 0, text: null, body: "", retryAfter: null };
    var response;
    try {
        response = fetch(AT_BASE + c.model + ":generateContent", {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-goog-api-key": c.key },
            body: JSON.stringify(body),
            timeout: cfg.timeout
        });
    } catch (e) {
        res.body = String(e);
        return res;
    }
    if (!response) return res;

    res.status = response.status || 0;
    try { res.body = response.text() || ""; } catch (e2) { res.body = ""; }
    try {
        var ra = response.header("retry-after");
        if (ra !== null && ra !== undefined && ra !== "" && !isNaN(parseFloat(ra))) res.retryAfter = parseFloat(ra);
    } catch (e3) {}

    if (res.status >= 200 && res.status < 300) {
        try {
            var j = JSON.parse(res.body);
            var cand = j.candidates && j.candidates[0];
            var t = "";
            if (cand && cand.content && cand.content.parts) {
                for (var i = 0; i < cand.content.parts.length; i++) {
                    var part = cand.content.parts[i];
                    if (part && part.text && !part.thought) t += part.text;
                }
            }
            t = AT_clean(t);
            if (AT_trim(t)) {
                res.ok = true;
                res.text = t;
            } else {
                var fr = cand && cand.finishReason;
                var blockReason = j.promptFeedback && j.promptFeedback.blockReason;
                if (blockReason || (fr && /SAFETY|PROHIBITED|BLOCKLIST|SPII|RECITATION|IMAGE/i.test(fr))) res.blocked = true;
            }
        } catch (e4) {}
    }
    return res;
}

function AT_retryDelay(body) {
    var m = /retryDelay"\s*:\s*"(\d+(?:\.\d+)?)s/.exec(body || "");
    return m ? parseFloat(m[1]) : null;
}

// Thử một cặp model+key, có thử lại khi lỗi tạm thời. Không bao giờ ném lỗi.
function AT_attempt(cfg, c, system, user, temp) {
    var delays = [0, 3000]; // mỗi vòng thử 2 lần rồi chuyển sang cặp khác
    var useSampling = !(AT_state().nosamp);
    var lastStatus = 0;
    for (var a = 0; a < delays.length; a++) {
        if (a > 0) {
            if (delays[a]) sleep(delays[a]);
            AT_slot(cfg, c.id);
        }
        var r = AT_http(cfg, c, system, user, temp, useSampling);
        if (r.ok) return { text: r.text };
        if (r.blocked) return { text: null, blocked: true };

        var s = r.status;
        lastStatus = s;
        AT_log(c.model + " status=" + s + " lần " + (a + 1));

        if (s === 401 || s === 403 || (s === 400 && /API key not valid|API_KEY_INVALID|API key expired|location is not supported/i.test(r.body))) {
            AT_setCool("k:" + c.kid, 24 * AT_HOUR, "API key sai hoặc bị từ chối (mã " + s + ")");
            return { text: null };
        }
        if (s === 404 || (s === 400 && /model/i.test(r.body) && /(not found|not supported|is not available)/i.test(r.body))) {
            AT_setCool("m:" + c.model, 24 * AT_HOUR, "model " + c.model + " không tồn tại hoặc không được hỗ trợ");
            return { text: null };
        }
        if (s === 400) {
            // Có thể API không nhận Top P / Top K: bỏ chúng và thử lại ngay.
            if (useSampling && (cfg.topP !== null || cfg.topK !== null)) {
                useSampling = false;
                var st = AT_state();
                st.nosamp = true;
                AT_saveState(st);
                AT_log("API từ chối Top P/Top K, bỏ qua hai tham số này.");
                a--;
                continue;
            }
            AT_setCool("f:" + c.id, 5 * 60 * 1000, "Gemini từ chối yêu cầu (mã 400) ở model " + c.model);
            return { text: null };
        }
        if (s === 429) {
            var ra = r.retryAfter;
            if (ra === null) ra = AT_retryDelay(r.body);
            if (/PerDay|per day|daily/i.test(r.body)) {
                AT_setCool("c:" + c.id, AT_HOUR, "hết lượt trong ngày của model " + c.model);
                return { text: null };
            }
            // Vượt lượt theo phút: giãn rộng khoảng cách các lượt sau rồi chờ đúng thời gian Gemini yêu cầu.
            var st2 = AT_state();
            if (!st2.slow) st2.slow = {};
            st2.slow[c.id] = Date.now() + 120000;
            AT_saveState(st2);
            var wait = (ra !== null ? ra : 20) * 1000 + 500;
            if (a < delays.length - 1 && wait <= AT_SPILL) {
                sleep(wait);
                continue;
            }
            AT_setCool("c:" + c.id, Math.max(ra || 60, 30) * 1000, "vượt giới hạn lượt mỗi phút của model " + c.model);
            return { text: null };
        }
        if (s === 0 || s >= 500 || (s >= 200 && s < 300)) continue; // lỗi mạng, 5xx (quá tải), hoặc trả rỗng
        AT_setCool("f:" + c.id, 5 * 60 * 1000, "Gemini trả lỗi lạ (mã " + s + ") ở model " + c.model);
        return { text: null };
    }
    // Lỗi tạm thời: chỉ tạm ngưng cặp này 10 giây để cặp khác (hoặc chính nó sau đó) thử lại.
    AT_setCool("f:" + c.id, 10 * 1000, "lỗi mạng hoặc máy chủ Gemini (mã " + (lastStatus || "không phản hồi") + ") ở model " + c.model);
    return { text: null };
}

// Chọn cặp model+key: ưu tiên theo thứ tự model; trong cùng model chọn key đang rảnh nhất.
function AT_complete(cfg, system, user, temp) {
    var combos = [];
    for (var m0 = 0; m0 < cfg.models.length; m0++) {
        for (var k0 = 0; k0 < cfg.keys.length; k0++) {
            combos.push({
                model: cfg.models[m0], key: cfg.keys[k0].key, kid: cfg.keys[k0].kid,
                id: cfg.models[m0] + "|" + cfg.keys[k0].kid, mi: m0
            });
        }
    }
    var start = Date.now();
    var tried = {};
    var reasons = [];
    sleep(Math.floor(Math.random() * 200)); // lệch nhẹ để các luồng không giành cùng một lượt

    while (Date.now() - start < AT_MAX_WAIT) {
        var st = AT_state();
        var now = Date.now();
        var bestByModel = {}, minW = null, usable = 0;
        for (var i = 0; i < combos.length; i++) {
            var c = combos[i];
            if ((tried[c.id] || 0) >= AT_CYCLES) continue;
            if (AT_isCool(st, "m:" + c.model) || AT_isCool(st, "k:" + c.kid) || AT_isCool(st, "c:" + c.id) || AT_isCool(st, "f:" + c.id)) continue;
            usable++;
            var w = AT_waitFor(st, c.id, cfg, now);
            if (!bestByModel[c.mi] || w < bestByModel[c.mi].w) bestByModel[c.mi] = { c: c, w: w };
            if (minW === null || w < minW) minW = w;
        }

        if (!usable) {
            // Chỉ chờ khi lý do là tạm thời và ngắn (lỗi mạng, 429 theo phút). Hết lượt ngày hoặc key sai thì dừng ngay.
            var soonest = null;
            for (var j = 0; j < combos.length; j++) {
                var cc = combos[j];
                if ((tried[cc.id] || 0) >= AT_CYCLES) continue;
                if (AT_isCool(st, "m:" + cc.model) || AT_isCool(st, "k:" + cc.kid)) continue;
                var until = Math.max((st.cool && st.cool["c:" + cc.id]) || 0, (st.cool && st.cool["f:" + cc.id]) || 0);
                if (until > now && (soonest === null || until - now < soonest)) soonest = until - now;
            }
            if (soonest !== null && soonest <= AT_SPILL) {
                sleep(soonest + 300);
                continue;
            }
            return { text: null, reason: reasons.length ? reasons.join("; ") : (AT_why(st, combos) || "không còn model hoặc key khả dụng") };
        }

        var best = null, bestW = 0;
        for (var mi = 0; mi < cfg.models.length; mi++) {
            var cand = bestByModel[mi];
            if (cand && cand.w <= AT_SPILL) { best = cand.c; bestW = cand.w; break; }
        }
        if (best === null) {
            // Mọi model đều phải chờ quá 20 giây: dừng và báo lỗi, không chờ tiếp.
            return { text: null, reason: "phải chờ hơn " + Math.round(AT_SPILL / 1000) + " giây mới tới lượt gọi (giới hạn số lượt mỗi phút hoặc Gemini quá tải)" };
        }

        AT_reserve(cfg, best.id, now + bestW);
        if (bestW > 0) sleep(bestW);
        var r = AT_attempt(cfg, best, system, user, temp);
        if (r.text) return r;
        if (r.blocked) return r;
        tried[best.id] = (tried[best.id] || 0) + 1;
        var why = AT_why(AT_state(), [best]);
        if (why && reasons.indexOf(why) < 0) reasons.push(why);
    }
    return { text: null, reason: reasons.length ? reasons.join("; ") : "chờ quá lâu mà vẫn không gọi được Gemini (quá tải hoặc giới hạn lượt mỗi phút)" };
}

// ---------- dịch theo khối ----------

function AT_fallbackOf(items, idxs, out) {
    for (var i = 0; i < idxs.length; i++) out[idxs[i]] = items[idxs[i]].src;
}

// Hỏi AI về các dòng idxs. Trả { status: "ok"|"blocked"|"fail", map }, map[chỉ_số_dòng] = văn bản.
function AT_ask(cfg, items, idxs, note, stats) {
    var system = AT_system(cfg, note);
    var user = AT_buildUser(items, idxs);
    stats.calls++;
    var r = AT_complete(cfg, system, user, cfg.temperature);
    if (r.blocked) return { status: "blocked" };
    if (!r.text) return { status: "fail", reason: r.reason };
    var got = AT_parseLoose(r.text, idxs.length);
    var map = {};
    for (var i = 0; i < idxs.length; i++) {
        var v = got[i + 1];
        if (v !== undefined && v !== "") map[idxs[i]] = v;
    }
    return { status: "ok", map: map };
}

function AT_cacheGet(key) {
    try {
        var c = cacheStorage.getItem(key);
        if (c) {
            var a = JSON.parse(c);
            if (a && a.length !== undefined) return a;
        }
    } catch (e) {}
    return null;
}

function AT_cachePut(key, arr) {
    try {
        var s = JSON.stringify(arr);
        if (s.length > 150000) return;
        cacheStorage.setItem(key, s);
        var idx = [];
        try { idx = JSON.parse(cacheStorage.getItem("at_idx") || "[]"); } catch (e1) { idx = []; }
        idx.push(key);
        while (idx.length > 80) {
            var old = idx.shift();
            try { cacheStorage.removeItem(old); } catch (e2) {}
        }
        cacheStorage.setItem("at_idx", JSON.stringify(idx));
    } catch (e) {}
}

function AT_runChunk(cfg, items, depth, stats) {
    var all = [];
    for (var i = 0; i < items.length; i++) all.push(i);

    var cacheKey = "at_c_" + AT_hash(cfg.sig + "|" + items.map(function (x) { return x.src; }).join("\n"));
    var cached = AT_cacheGet(cacheKey);
    if (cached && cached.length === items.length) {
        stats.cached += items.length;
        return cached;
    }

    var out = new Array(items.length);
    if (stats.dead) {
        AT_fallbackOf(items, all, out);
        stats.fallback += items.length;
        return out;
    }

    // Lượt 1: gửi cả khối trong một yêu cầu.
    var r1 = AT_ask(cfg, items, all, null, stats);
    if (r1.status === "fail") {
        stats.dead = true;
        stats.reason = r1.reason;
        AT_log("Hết model/key khả dụng, dùng bản convert cho phần còn lại.");
        AT_fallbackOf(items, all, out);
        stats.fallback += items.length;
        return out;
    }
    if (r1.status === "blocked") {
        // Bị chặn nội dung: chia đôi để cô lập đoạn bị chặn.
        if (items.length > 1 && depth < 3) {
            var mid = Math.ceil(items.length / 2);
            return AT_runChunk(cfg, items.slice(0, mid), depth + 1, stats)
                .concat(AT_runChunk(cfg, items.slice(mid), depth + 1, stats));
        }
        AT_fallbackOf(items, all, out);
        stats.fallback += items.length;
        return out;
    }

    var redo = [];
    for (var j = 0; j < items.length; j++) {
        var cand = r1.map[j];
        if (cand !== undefined && AT_lineOK(items[j], cand)) out[j] = cand;
        else redo.push(j);
    }

    // Lượt 2 (tối đa một lần cho cả khối): gom các dòng thiếu hoặc nghi bịa/cắt để AI viết lại.
    if (redo.length && !stats.dead) {
        stats.suspect += redo.length;
        AT_log("Viết lại " + redo.length + "/" + items.length + " dòng thiếu hoặc nghi bịa/cắt.");
        var note = "Lưu ý quan trọng: lần dịch trước các mục này bị thiếu hoặc lệch so với văn bản (thêm hoặc thiếu ý, sai con số, sai dấu ngoặc). " +
            "Hãy viết lại sát nghĩa từng mục, độ dài tương đương văn bản, giữ nguyên mọi con số và dấu câu, tuyệt đối không thêm ý.";
        var r2 = AT_ask(cfg, items, redo, note, stats);
        var left = [];
        for (var q = 0; q < redo.length; q++) {
            var cand2 = r2.status === "ok" ? r2.map[redo[q]] : undefined;
            if (cand2 !== undefined && AT_lineOK(items[redo[q]], cand2)) {
                out[redo[q]] = cand2;
                stats.fixed++;
            } else {
                left.push(redo[q]);
            }
        }
        redo = left;
    }
    // Sau khi viết lại mà vẫn hỏng mới dùng bản convert.
    AT_fallbackOf(items, redo, out);
    stats.fallback += redo.length;
    stats.ai += items.length - redo.length;

    for (var z = 0; z < items.length; z++) out[z] = AT_finish(cfg, items[z], out[z]);
    if (!redo.length) AT_cachePut(cacheKey, out);
    return out;
}

function AT_run(text, from, to, source) {
    text = (text === null || text === undefined) ? "" : String(text);
    if (!AT_trim(text)) return Response.success(text);

    var cfg = AT_loadConfig(to);
    if (cfg.error) return Response.error(cfg.error);

    var rawLines = text.split(/\r?\n/);
    var items = [];
    var plan = []; // mỗi dòng: { raw: "..." } hoặc { idx: n, lead: "..." }
    var tocOnly = (source === "tableOfContent" && !cfg.rewriteToc);

    for (var i = 0; i < rawLines.length; i++) {
        var line = rawLines[i];
        var body = AT_trim(line);
        // Dòng trống và dòng chỉ có ký hiệu phân cách (***, ---, ...) giữ nguyên, không gửi AI.
        if (!body || !AT_hasLetter(body)) {
            plan.push({ raw: line });
            continue;
        }
        var lead = line.slice(0, line.indexOf(body.charAt(0)));
        var src = body;
        if (AT_cjkCount(body) > 0) {
            var q = AT_qt(body, source);
            if (q) src = AT_trim(q);
        }
        if (tocOnly) {
            plan.push({ raw: lead + src });
            continue;
        }
        items.push({ src: src });
        plan.push({ idx: items.length - 1, lead: lead });
    }

    // Gom thành các khối theo số ký tự và số dòng (thường cả chương là một khối).
    var chunks = [];
    var cur = [];
    var curLen = 0;
    for (var j = 0; j < items.length; j++) {
        var add = items[j].src.length + 6;
        if (cur.length && (curLen + add > cfg.chunkChars || cur.length >= cfg.chunkLines)) {
            chunks.push(cur);
            cur = [];
            curLen = 0;
        }
        cur.push(items[j]);
        curLen += add;
    }
    if (cur.length) chunks.push(cur);

    var stats = { ai: 0, cached: 0, fallback: 0, suspect: 0, fixed: 0, calls: 0, dead: false, reason: "" };
    var results = [];
    for (var c = 0; c < chunks.length; c++) {
        var part;
        try {
            part = AT_runChunk(cfg, chunks[c], 0, stats);
        } catch (e) {
            // Chốt chặn cuối: lỗi bất ngờ cũng không làm dừng cả lô dịch.
            AT_log("Lỗi bất ngờ: " + e);
            AT_log("Lỗi nội bộ, báo lỗi: " + e);
            return Response.error("Lỗi nội bộ của " + AT_NAME + " " + AT_VERSION + ": " + e);
            part = [];
            for (var f = 0; f < chunks[c].length; f++) part.push(chunks[c][f].src);
            stats.fallback += chunks[c].length;
        }
        for (var p = 0; p < part.length; p++) results.push(part[p]);
    }

    if (stats.dead) {
        AT_log("Báo lỗi: " + stats.reason);
        return Response.error("Gemini không dùng được: " + stats.reason + ".");
    }

    AT_log(AT_NAME + " " + AT_VERSION + ": goi=" + stats.calls + " ai=" + stats.ai + " cache=" + stats.cached +
        " convert=" + stats.fallback + " viet_lai=" + stats.fixed + "/" + stats.suspect);

    var outLines = [];
    for (var s = 0; s < plan.length; s++) {
        outLines.push(plan[s].raw !== undefined ? plan[s].raw : plan[s].lead + results[plan[s].idx]);
    }
    return Response.success(outLines.join("\n"));
}
