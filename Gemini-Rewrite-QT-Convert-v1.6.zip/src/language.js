load("defaults.js");
load("common.js");

// Phần gốc luôn là QT/Convert. Phần dịch là danh sách phong cách dịch người dùng đã đặt tên.
function execute() {
    var list = [{ id: "qt", name: "QT/Convert", type: "from" }];
    var styles = AT_styles();
    for (var i = 0; i < styles.length; i++) {
        list.push({ id: styles[i].id, name: styles[i].name, type: "to" });
    }
    return Response.success(list);
}
